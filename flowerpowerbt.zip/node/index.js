var Bridge = require('./lib/FlowerBridge');

module.exports = Bridge;
